/* ============================================================
   INVENTORY MODULE — PARV
   Owns product CRUD, stock adjustments, search and low-stock report.
   ============================================================ */
import { $, state, saveState, notifyChange, locationName, findProduct, escapeHTML, toast } from '../../js/store.js';

function productTable(products, showActions = true) {
  if (!products.length) return '<p class="sub">No matching products found.</p>';
  return `<table><thead><tr><th>ID</th><th>Product</th><th>Quantity</th><th>Location</th>${showActions ? '<th>Action</th>' : ''}</tr></thead><tbody>${products.map(product =>
    `<tr><td>${product.id}</td><td class="product-name">${escapeHTML(product.name)}</td><td><span class="pill ${product.quantity < 10 ? 'low' : ''}">${product.quantity} units</span></td><td>${escapeHTML(locationName(product.location))}</td>${showActions ? `<td><button class="danger-button" data-delete-product="${product.id}">Delete</button></td>` : ''}</tr>`
  ).join('')}</tbody></table>`;
}

export function refreshInventory() {
  const search = $('inventory-search').value.trim().toLowerCase();
  const sorted = [...state.inventory].sort((a, b) => a.id - b.id);
  const filtered = sorted.filter(product => String(product.id).includes(search) || product.name.toLowerCase().includes(search));
  $('inventory-table').innerHTML = productTable(filtered);
  $('low-stock-table').innerHTML = productTable(sorted.filter(product => product.quantity < 10), false);
  $('inventory-total-products').textContent = state.inventory.length;
  $('inventory-total-units').textContent = state.inventory.reduce((total, product) => total + product.quantity, 0);
  $('inventory-low-stock').textContent = state.inventory.filter(product => product.quantity < 10).length;
  const options = state.locations.map(location => `<option value="${location.id}">${location.id} — ${escapeHTML(location.name)}</option>`).join('');
  $('product-location').innerHTML = options;
  if (!state.locations.some(location => location.id === Number($('product-location').value)) && state.locations.length) {
    $('product-location').value = String(state.locations[0].id);
  }
}

export function initInventory() {
  $('show-add').addEventListener('click', () => $('add-form').classList.toggle('hidden'));
  $('cancel-add').addEventListener('click', () => $('add-form').classList.add('hidden'));

  $('add-form').addEventListener('submit', event => {
    event.preventDefault();
    const id = Number($('product-id').value);
    const name = $('product-name').value.trim();
    const quantity = Number($('product-qty').value);
    const location = Number($('product-location').value);
    if (!Number.isInteger(id) || id <= 0 || !name || !Number.isInteger(quantity) || quantity < 0) return toast('Enter valid product details.');
    if (findProduct(id)) return toast('That product ID already exists.');
    if (!state.locations.some(item => item.id === location)) return toast('Choose a valid warehouse location.');
    state.inventory.push({ id, name, quantity, location });
    saveState(); notifyChange(); event.target.reset(); $('add-form').classList.add('hidden'); toast('Product added successfully.');
  });

  $('inventory-table').addEventListener('click', event => {
    const button = event.target.closest('[data-delete-product]');
    if (!button) return;
    const id = Number(button.dataset.deleteProduct);
    if (!confirm(`Delete product ${id}?`)) return;
    const originalLength = state.inventory.length;
    state.inventory = state.inventory.filter(product => product.id !== id);
    if (state.inventory.length === originalLength) return toast('Product not found.');
    saveState(); notifyChange(); toast('Product deleted.');
  });

  $('adjust-form').addEventListener('submit', event => {
    event.preventDefault();
    const product = findProduct($('adjust-id').value);
    const change = Number($('adjust-change').value);
    if (!product) return toast('Product not found.');
    if (!Number.isInteger(change) || product.quantity + change < 0) return toast('Stock cannot go below zero.');
    product.quantity += change;
    saveState(); notifyChange(); event.target.reset(); toast('Stock quantity updated.');
  });

  $('inventory-search-form').addEventListener('submit', event => event.preventDefault());
  $('inventory-search').addEventListener('input', refreshInventory);
  $('clear-search').addEventListener('click', () => { $('inventory-search').value = ''; refreshInventory(); });
  window.addEventListener('warehouse:changed', refreshInventory);
  refreshInventory();
}

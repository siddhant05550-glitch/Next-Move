/* ============================================================
   ORDERS MODULE — SHIVAM
   Owns order queue, FIFO processing, stock validation and order history.
   ============================================================ */
import { $, state, saveState, notifyChange, findProduct, escapeHTML, toast } from '../../js/store.js';
import { shortestPath } from '../graph/graph.js';

function renderOrderStats() {
  const pending = state.orders.filter(order => order.status === 'Pending');
  $('orders-pending-count').textContent = pending.length;
  $('orders-processed-count').textContent = state.orders.filter(order => order.status === 'Processed').length;
  $('orders-closed-count').textContent = state.orders.filter(order => ['Out of Stock', 'Cancelled'].includes(order.status)).length;
  $('orders-next-id').textContent = pending.length ? `#${pending[0].order_id}` : '—';
}

function renderOrders() {
  renderOrderStats();
  const pending = state.orders.filter(order => order.status === 'Pending');
  const history = state.orders.filter(order => order.status !== 'Pending');
  const ordered = [...pending, ...history];
  $('orders-table').innerHTML = ordered.length ? `<table><thead><tr><th>Queue / Order</th><th>Product</th><th>Quantity</th><th>Status</th><th>Details / pick route</th></tr></thead><tbody>${ordered.map((order, index) =>
    `<tr><td>${order.status === 'Pending' ? `Queue #${index + 1} · ` : ''}#${order.order_id}</td><td class="product-name">${escapeHTML(order.product_name)}</td><td>${order.quantity}</td><td><span class="pill ${order.status === 'Pending' || order.status === 'Out of Stock' ? 'low' : ''}">${escapeHTML(order.status)}</span></td><td>${escapeHTML(order.note || '—')}</td></tr>`
  ).join('')}</tbody></table>` : '<p class="sub">No orders yet. Create your first order above.</p>';
  const options = state.inventory.map(product => `<option value="${product.id}">${product.id} — ${escapeHTML(product.name)} (${product.quantity} available)</option>`).join('');
  $('order-product').innerHTML = options || '<option value="">No products available</option>';
  $('order-product').disabled = state.inventory.length === 0;
}

export function refreshOrders() { renderOrders(); }

export function initOrders() {
  $('order-form').addEventListener('submit', event => {
    event.preventDefault();
    const product = findProduct($('order-product').value);
    const quantity = Number($('order-qty').value);
    if (!product) return toast('Select a product first.');
    if (!Number.isInteger(quantity) || quantity <= 0) return toast('Quantity must be at least 1.');
    const order = {
      order_id: state.nextOrderId++, product_id: product.id, product_name: product.name,
      quantity, status: 'Pending', note: ''
    };
    state.orders.push(order);
    saveState(); notifyChange(); event.target.reset();
    toast(`Order #${order.order_id} added to the FIFO queue.`);
    if (product.quantity < quantity) toast(`Warning: only ${product.quantity} unit(s) currently in stock.`);
  });

  $('process-order').addEventListener('click', () => {
    const order = state.orders.find(item => item.status === 'Pending');
    if (!order) return toast('There are no pending orders.');
    const product = findProduct(order.product_id);
    if (!product) {
      order.status = 'Cancelled';
      order.note = 'Product no longer exists in inventory.';
    } else if (product.quantity < order.quantity) {
      order.status = 'Out of Stock';
      order.note = `Needed ${order.quantity}; only ${product.quantity} available. Stock was not changed.`;
    } else {
      // Follow the warehouse rule: deduct the stock, then attach an optimized pick route.
      product.quantity -= order.quantity;
      order.status = 'Processed';
      const dispatch = state.locations.find(location => location.id === 1) || state.locations[0];
      const route = dispatch ? shortestPath(dispatch.id, product.location) : null;
      order.note = route
        ? `Pick route: ${route.names.join(' → ')} (${route.distance} m)`
        : 'Stock deducted, but no open route to the product location.';
    }
    saveState(); notifyChange(); toast(`Order #${order.order_id}: ${order.status}.`);
  });

  $('refresh-orders').addEventListener('click', () => { renderOrders(); toast('Order queue refreshed.'); });
  window.addEventListener('warehouse:changed', renderOrders);
  renderOrders();
}

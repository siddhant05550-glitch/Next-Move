/* ============================================================
   GRAPH MODULE — SIDDHANT
   Owns warehouse locations, paths, BFS, DFS, Dijkstra and rerouting.
   ============================================================ */
import { $, state, saveState, notifyChange, locationName, escapeHTML, toast } from '../../js/store.js';

export function shortestPath(start, end) {
  start = Number(start); end = Number(end);
  const ids = state.locations.map(location => location.id);
  if (!ids.includes(start) || !ids.includes(end)) return null;
  const distance = {}, previous = {}, visited = new Set();
  ids.forEach(id => { distance[id] = Infinity; });
  distance[start] = 0;

  while (visited.size < ids.length) {
    let current = null;
    for (const id of ids) {
      if (!visited.has(id) && (current === null || distance[id] < distance[current])) current = id;
    }
    if (current === null || distance[current] === Infinity) break;
    if (current === end) break;
    visited.add(current);

    for (const path of state.paths) {
      if (path.blocked) continue;
      const neighbor = path.a === current ? path.b : path.b === current ? path.a : null;
      if (neighbor === null || visited.has(neighbor)) continue;
      const nextDistance = distance[current] + Number(path.distance);
      if (nextDistance < distance[neighbor]) {
        distance[neighbor] = nextDistance;
        previous[neighbor] = current;
      }
    }
  }

  if (distance[end] === Infinity) return null;
  const idsInPath = [end];
  while (idsInPath[0] !== start) {
    const parent = previous[idsInPath[0]];
    if (parent === undefined) return null;
    idsInPath.unshift(parent);
  }
  return { distance: distance[end], ids: idsInPath, names: idsInPath.map(locationName) };
}

function neighbors(id) {
  return state.paths
    .filter(path => !path.blocked && (path.a === id || path.b === id))
    .map(path => path.a === id ? path.b : path.a)
    .sort((a, b) => a - b);
}

function traverse(start, type) {
  start = Number(start);
  if (!state.locations.some(location => location.id === start)) return [];
  const visited = new Set();
  const result = [];
  if (type === 'bfs') {
    const queue = [start]; visited.add(start);
    while (queue.length) {
      const current = queue.shift(); result.push(locationName(current));
      for (const neighbor of neighbors(current)) {
        if (!visited.has(neighbor)) { visited.add(neighbor); queue.push(neighbor); }
      }
    }
  } else {
    const visit = current => {
      visited.add(current); result.push(locationName(current));
      for (const neighbor of neighbors(current)) if (!visited.has(neighbor)) visit(neighbor);
    };
    visit(start);
  }
  return result;
}

function renderLocationSelects() {
  const options = state.locations.map(location =>
    `<option value="${location.id}">${location.id} — ${escapeHTML(location.name)}</option>`
  ).join('');
  ['route-start', 'route-end', 'path-a', 'path-b', 'traversal-start', 'product-location'].forEach(id => {
    const select = $(id);
    if (select) {
      const previous = select.value;
      select.innerHTML = options;
      if ([...select.options].some(option => option.value === previous)) select.value = previous;
    }
  });
  if (state.locations.some(location => location.id === 1)) $('route-start').value = '1';
  if (state.locations.some(location => location.id === 4)) $('route-end').value = '4';
}

function renderLocations() {
  $('location-cards').innerHTML = state.locations.map(location =>
    `<div class="location-card"><div class="location-number">${location.id}</div><b>${escapeHTML(location.name)}</b><small>Warehouse node ${location.id}</small></div>`
  ).join('') || '<p class="sub">No locations configured yet.</p>';
}

function renderPaths() {
  $('paths-table').innerHTML = state.paths.length ? `<table><thead><tr><th>From</th><th>To</th><th>Distance</th><th>Status</th><th>Action</th></tr></thead><tbody>${state.paths.map((path, index) =>
    `<tr><td>${escapeHTML(locationName(path.a))}</td><td>${escapeHTML(locationName(path.b))}</td><td>${path.distance} m</td><td>${path.blocked ? '<span class="path-blocked">Blocked</span>' : 'Open'}</td><td><button class="secondary" data-toggle-path="${index}">${path.blocked ? 'Reopen' : 'Block path'}</button></td></tr>`
  ).join('')}</tbody></table>` : '<p class="sub">No paths configured.</p>';
}

export function refreshGraph() {
  renderLocationSelects();
  renderLocations();
  renderPaths();
}

export function initGraph() {
  $('graph-add-location-form').addEventListener('submit', event => {
    event.preventDefault();
    const name = $('graph-location-name').value.trim();
    if (!name) return toast('Enter a location name.');
    if (state.locations.length >= 20) return toast('Maximum of 20 locations reached.');
    const id = state.locations.reduce((max, location) => Math.max(max, location.id), 0) + 1;
    state.locations.push({ id, name });
    saveState(); notifyChange(); event.target.reset(); toast(`Location ${id} added.`);
  });

  $('path-form').addEventListener('submit', event => {
    event.preventDefault();
    const a = Number($('path-a').value), b = Number($('path-b').value), distance = Number($('path-distance').value);
    if (!state.locations.some(l => l.id === a) || !state.locations.some(l => l.id === b) || a === b || !Number.isInteger(distance) || distance <= 0) {
      return toast('Choose two different valid locations and a positive distance.');
    }
    let path = state.paths.find(item => (item.a === a && item.b === b) || (item.a === b && item.b === a));
    if (path) { path.distance = distance; path.blocked = false; }
    else state.paths.push({ a, b, distance, blocked: false });
    saveState(); notifyChange(); event.target.reset(); toast('Path added / updated.');
  });

  $('paths-table').addEventListener('click', event => {
    const button = event.target.closest('[data-toggle-path]');
    if (!button) return;
    const path = state.paths[Number(button.dataset.togglePath)];
    if (!path) return;
    path.blocked = !path.blocked;
    saveState(); notifyChange(); toast(path.blocked ? 'Path blocked. Routes will avoid it.' : 'Path reopened.');
  });

  $('route-form').addEventListener('submit', event => {
    event.preventDefault();
    const route = shortestPath($('route-start').value, $('route-end').value);
    $('route-result').innerHTML = route
      ? `<b>Shortest route · ${route.distance} m</b><br>${route.names.map(escapeHTML).join(' <span style="color:#356df3">→</span> ')}`
      : 'No open route found between these locations.';
  });

  $('traversal-form').addEventListener('submit', event => {
    event.preventDefault();
    const type = $('traversal-type').value;
    const output = traverse($('traversal-start').value, type);
    $('traversal-result').innerHTML = output.length
      ? `<b>${type.toUpperCase()} traversal · ${output.length} location(s) reached</b><br>${output.map(escapeHTML).join(' <span style="color:#356df3">→</span> ')}`
      : 'No reachable locations found.';
  });

  window.addEventListener('warehouse:changed', refreshGraph);
  refreshGraph();
}

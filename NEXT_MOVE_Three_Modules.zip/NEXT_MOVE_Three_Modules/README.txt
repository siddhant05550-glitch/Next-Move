NEXT MOVE — THREE MODULE TEAM PROJECT (HTML / CSS / JavaScript ONLY)

TEAM DIVISION
1. GRAPH — Siddhant
   File: modules/graph/graph.js
   Owns warehouse locations, connections/paths, path blocking/reopening, BFS, DFS,
   Dijkstra shortest path and rerouting.

2. INVENTORY — Parv
   File: modules/inventory/inventory.js
   Owns product add/delete, product search, stock quantity adjustments and low-stock report.

3. ORDERS — Shivam
   File: modules/orders/orders.js
   Owns order creation, FIFO queue processing, stock validation, order history and pick-route note.

SHARED FILES
- index.html: page layout and all module sections
- style.css: common design and responsive layout
- js/store.js: shared browser state, localStorage persistence and common helpers
- js/app.js: navigation and dashboard only

HOW TO RUN (NO PYTHON)
1. Extract this ZIP.
2. Open the extracted NEXT_MOVE_Three_Modules folder in VS Code.
3. Install the Live Server extension if needed.
4. Right-click index.html and choose "Open with Live Server".
5. The site will open at a local address similar to http://127.0.0.1:5500.

IMPORTANT
- Data is stored in browser localStorage and stays in that browser unless cleared.
- This HTML/JS demonstration is separate from the C/C++ implementation. It does not call the C/C++ functions directly.
- The c_cpp_reference folder contains the original C/C++ files to help the team coordinate the equivalent modules.
- This is a client-side demo, not a secure multi-user production system.

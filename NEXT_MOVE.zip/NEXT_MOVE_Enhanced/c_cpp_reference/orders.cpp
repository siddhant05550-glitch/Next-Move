#include <iostream>
#include <iomanip>
#include <limits>
#include <queue>
#include <vector>
#include "orders.h"
#include "inventory.h"
#include "graph.h"

using namespace std;

static int rankForPriority(const string &priority)
{
    if (priority == "Critical")
        return 4;
    if (priority == "High")
        return 3;
    if (priority == "Normal")
        return 2;
    if (priority == "Low")
        return 1;
    return 2;
}

bool OrderPriorityCompare::operator()(const Order &left, const Order &right) const
{
    const int leftRank = rankForPriority(left.priority);
    const int rightRank = rankForPriority(right.priority);
    if (leftRank != rightRank)
        return leftRank < rightRank;
    return left.orderId > right.orderId;
}

Order::Order(int oid, int pid, const string &pname, int qty,
             const string &customer, const string &priorityLevel)
    : orderId(oid), productId(pid), productName(pname), customerName(customer),
      quantity(qty), priority(priorityLevel), status("New"),
      note("Customer order received; waiting in priority queue."), stockDeducted(false)
{
}

void Order::display() const
{
    cout << "\nOrder ID     : #" << orderId;
    cout << "\nCustomer     : " << customerName;
    cout << "\nProduct      : " << productName << " (SKU " << productId << ")";
    cout << "\nQuantity     : " << quantity;
    cout << "\nPriority     : " << priority;
    cout << "\nStatus       : " << status;
    if (!note.empty())
        cout << "\nDetails      : " << note;
    cout << "\n----------------------------------------------";
}

OrderManager::OrderManager(int startId) : nextOrderId(startId) {}

int OrderManager::priorityRank(const string &priority)
{
    return rankForPriority(priority);
}

Order *OrderManager::findOrder(int orderId)
{
    for (size_t i = 0; i < orders.size(); ++i)
        if (orders[i].orderId == orderId)
            return &orders[i];
    return NULL;
}

const Order *OrderManager::findOrder(int orderId) const
{
    for (size_t i = 0; i < orders.size(); ++i)
        if (orders[i].orderId == orderId)
            return &orders[i];
    return NULL;
}

int OrderManager::addOrder(int productId, int quantity, const string &customer, const string &priority)
{
    if (quantity <= 0)
    {
        cout << "\nQuantity must be at least 1!\n";
        return -1;
    }
    if (customer.empty())
    {
        cout << "\nCustomer name cannot be empty!\n";
        return -1;
    }
    if (!(priority == "Critical" || priority == "High" || priority == "Normal" || priority == "Low"))
    {
        cout << "\nInvalid priority! Use Critical, High, Normal or Low.\n";
        return -1;
    }

    Product *product = inv_search(productId, NULL, NULL);
    if (product == NULL)
    {
        cout << "\nProduct ID " << productId << " not found in inventory!\n";
        return -1;
    }

    Order order(nextOrderId++, productId, product->name, quantity, customer, priority);
    orders.push_back(order);
    cout << "\nCustomer order #" << order.orderId << " created with " << priority << " priority.";
    if (product->quantity < quantity)
        cout << " Warning: only " << product->quantity << " unit(s) in stock.";
    cout << "\n";
    return order.orderId;
}

void OrderManager::displayPending() const
{
    priority_queue<Order, vector<Order>, OrderPriorityCompare> queue;
    for (size_t i = 0; i < orders.size(); ++i)
        if (orders[i].status == "New")
            queue.push(orders[i]);

    if (queue.empty())
    {
        cout << "\nNo new orders are waiting for picking!\n";
        return;
    }

    cout << "\n===== PRIORITY PICK QUEUE (heap top first) =====";
    int position = 1;
    while (!queue.empty())
    {
        const Order current = queue.top();
        queue.pop();
        cout << "\nQueue position " << position++ << "  |  " << current.priority << " priority";
        current.display();
    }
    cout << endl;
}

void OrderManager::displayHistory() const
{
    if (orders.empty())
    {
        cout << "\nNo orders have been placed yet!\n";
        return;
    }
    cout << "\n===== ALL ORDERS / WORKFLOW HISTORY =====";
    for (size_t i = 0; i < orders.size(); ++i)
        orders[i].display();
    cout << endl;
}

bool OrderManager::searchOrder(int orderId) const
{
    const Order *order = findOrder(orderId);
    if (!order)
    {
        cout << "\nOrder not found!\n";
        return false;
    }
    order->display();
    cout << endl;
    return true;
}

bool OrderManager::cancelOrder(int orderId)
{
    Order *order = findOrder(orderId);
    if (!order || !(order->status == "New" || order->status == "Out of Stock" ||
                    order->status == "Picking" || order->status == "Packed"))
    {
        cout << "\nOrder not found or cannot be cancelled after dispatch.\n";
        return false;
    }

    if (order->stockDeducted)
    {
        inv_update_quantity(order->productId, order->quantity);
        order->stockDeducted = false;
    }
    order->status = "Cancelled";
    order->note = "Cancelled before dispatch; reserved stock restored if picking had started.";
    cout << "\nOrder #" << orderId << " cancelled.\n";
    return true;
}

bool OrderManager::processNextOrder()
{
    priority_queue<Order, vector<Order>, OrderPriorityCompare> queue;
    for (size_t i = 0; i < orders.size(); ++i)
        if (orders[i].status == "New")
            queue.push(orders[i]);

    if (queue.empty())
    {
        cout << "\nNo new order to pick!\n";
        return false;
    }

    const Order next = queue.top();
    Order *current = findOrder(next.orderId);
    if (!current)
        return false;

    Product *product = inv_search(current->productId, NULL, NULL);
    if (product == NULL)
    {
        current->status = "Cancelled";
        current->note = "Product no longer exists in inventory.";
        current->display();
        return false;
    }
    if (product->quantity < current->quantity)
    {
        current->status = "Out of Stock";
        current->note = "Needed " + to_string(current->quantity) + ", only " +
                        to_string(product->quantity) + " available. Update quantity or restock.";
        cout << "\nCannot start picking because stock is insufficient.";
        current->display();
        cout << endl;
        return false;
    }

    int route[MAX_LOCATIONS], length = 0;
    const int distance = graph_shortest_path(DISPATCH_DOCK, product->location, route, &length);
    if (distance < 0)
    {
        current->note = "No open route from dispatch dock to the product location. Order remains in queue.";
        cout << "\nNo open pick route. Reopen a path and retry.\n";
        return false;
    }

    if (inv_update_quantity(current->productId, -current->quantity) != 1)
    {
        current->note = "Stock could not be reserved. Check the inventory quantity.";
        cout << "\nStock reservation failed.\n";
        return false;
    }

    current->stockDeducted = true;
    current->status = "Picking";
    current->note = "Dijkstra pick route: ";
    for (int i = 0; i < length; ++i)
    {
        if (i)
            current->note += " -> ";
        current->note += graph_location_name(route[i]);
    }
    current->note += " (" + to_string(distance) + " m). Stock reserved.";

    cout << "\n===== PICKING STARTED =====";
    current->display();
    cout << endl;
    return true;
}

bool OrderManager::advanceOrder(int orderId)
{
    Order *order = findOrder(orderId);
    if (!order)
    {
        cout << "\nOrder not found!\n";
        return false;
    }

    if (order->status == "Picking")
    {
        order->status = "Packed";
        order->note = "Items picked and packed; ready for dispatch.";
    }
    else if (order->status == "Packed")
    {
        order->status = "Out for Delivery";
        order->note = "Dispatched from the warehouse; delivery is in progress.";
    }
    else if (order->status == "Out for Delivery")
    {
        order->status = "Delivered";
        order->note = "Delivery completed.";
    }
    else
    {
        cout << "\nOnly Picking, Packed or Out for Delivery orders can advance. Current status: "
             << order->status << ".\n";
        return false;
    }

    cout << "\nOrder #" << orderId << " moved to: " << order->status << "\n";
    return true;
}

bool OrderManager::updateQuantity(int orderId, int quantity)
{
    Order *order = findOrder(orderId);
    if (!order || !(order->status == "New" || order->status == "Out of Stock"))
    {
        cout << "\nQuantity can only be changed before picking starts.\n";
        return false;
    }
    if (quantity <= 0)
    {
        cout << "\nQuantity must be at least 1!\n";
        return false;
    }
    order->quantity = quantity;
    order->status = "New";
    order->note = "Quantity updated; waiting in the priority queue.";
    Product *product = inv_search(order->productId, NULL, NULL);
    cout << "\nQuantity for order #" << orderId << " updated to " << quantity << ".";
    if (product && product->quantity < quantity)
        cout << " Warning: only " << product->quantity << " unit(s) currently in stock.";
    cout << "\n";
    return true;
}

void OrderManager::checkAvailability(int productId, int quantity) const
{
    Product *product = inv_search(productId, NULL, NULL);
    if (product == NULL)
    {
        cout << "\nProduct not found!\n";
        return;
    }
    if (quantity <= 0)
    {
        cout << "\nRequired quantity must be at least 1!\n";
        return;
    }

    cout << "\n"
         << product->name << ": " << product->quantity << " unit(s) available at "
         << graph_location_name(product->location) << ".";
    if (product->quantity >= quantity)
        cout << "\nAvailable for an order of " << quantity << ".\n";
    else
        cout << "\nInsufficient stock by " << quantity - product->quantity << " unit(s).\n";
}

int OrderManager::pendingCount() const
{
    int count = 0;
    for (size_t i = 0; i < orders.size(); ++i)
        if (orders[i].status == "New")
            ++count;
    return count;
}

int OrderManager::processedCount() const
{
    int count = 0;
    for (size_t i = 0; i < orders.size(); ++i)
        if (orders[i].status == "Picking" || orders[i].status == "Packed" ||
            orders[i].status == "Out for Delivery" || orders[i].status == "Delivered")
            ++count;
    return count;
}

#ifdef STANDALONE
static int readInt(const string &prompt)
{
    int x;
    cout << prompt;
    while (!(cin >> x))
    {
        if (cin.eof())
            exit(0);
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Please enter a number: ";
    }
    return x;
}

int main()
{
    inv_init();
    graph_init();
    graph_add_location("Dispatch dock");
    graph_add_location("Aisle A");
    graph_add_location("Aisle B");
    graph_add_path(1, 2, 4);
    graph_add_path(1, 3, 5);
    graph_add_path(2, 3, 3);
    inv_add(101, "Copper wire roll", 40, 2);
    inv_add(205, "LED panel", 12, 3);
    inv_add(342, "Cooler box", 6, 3);

    OrderManager manager;
    int choice;
    do
    {
        cout << "\n\n===== ORDER MANAGEMENT SYSTEM =====";
        cout << "\n1. Place customer order";
        cout << "\n2. View priority queue";
        cout << "\n3. Start next pick";
        cout << "\n4. Advance an order workflow";
        cout << "\n5. Update order quantity";
        cout << "\n6. Search order";
        cout << "\n7. Cancel order";
        cout << "\n8. Check product availability";
        cout << "\n9. Order history";
        cout << "\n0. Exit";
        choice = readInt("\n\nEnter choice: ");
        switch (choice)
        {
        case 1:
        {
            int pid = readInt("Product ID: ");
            int qty = readInt("Quantity: ");
            string customer;
            cout << "Customer name: ";
            cin >> ws;
            getline(cin, customer);
            int p = readInt("Priority (1 Critical, 2 High, 3 Normal, 4 Low): ");
            const string priority = p == 1 ? "Critical" : p == 2 ? "High"
                                                      : p == 4   ? "Low"
                                                                 : "Normal";
            manager.addOrder(pid, qty, customer, priority);
            break;
        }
        case 2:
            manager.displayPending();
            break;
        case 3:
            manager.processNextOrder();
            break;
        case 4:
            manager.advanceOrder(readInt("Order ID: "));
            break;
        case 5:
            manager.updateQuantity(readInt("Order ID: "), readInt("New quantity: "));
            break;
        case 6:
            manager.searchOrder(readInt("Order ID: "));
            break;
        case 7:
            manager.cancelOrder(readInt("Order ID: "));
            break;
        case 8:
            manager.checkAvailability(readInt("Product ID: "), readInt("Required quantity: "));
            break;
        case 9:
            manager.displayHistory();
            break;
        case 0:
            cout << "\nExiting...\n";
            break;
        default:
            cout << "\nInvalid choice!\n";
        }
    } while (choice != 0);

    inv_free();
    return 0;
}
#endif

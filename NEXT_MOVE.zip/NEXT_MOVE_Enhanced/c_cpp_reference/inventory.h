#ifndef INVENTORY_H
#define INVENTORY_H

#ifdef __cplusplus
extern "C"
{
#endif

#define HASH_SIZE 10
#define NAME_LEN 40

    typedef struct Product
    {
        int id;
        char name[NAME_LEN];
        int quantity;
        int location;
    } Product;

    void inv_init(void);

    int inv_add(int id, const char *name, int quantity, int location);

    Product *inv_search(int id, int *bucket, int *steps);

    int inv_delete(int id);

    int inv_update_quantity(int id, int change);

    void inv_display_sorted(void);
    void inv_display_hash_table(void);
    int inv_display_low_stock(int threshold);

    int inv_count(void);
    int inv_total_units(void);
    int inv_low_stock_count(int threshold);

    void inv_free(void);

#ifdef __cplusplus
}
#endif

#endif

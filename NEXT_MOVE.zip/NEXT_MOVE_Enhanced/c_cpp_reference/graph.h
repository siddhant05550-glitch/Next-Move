#ifndef GRAPH_H
#define GRAPH_H

#ifdef __cplusplus
extern "C"
{
#endif

#define MAX_LOCATIONS 20
#define LOC_NAME_LEN 30

    void graph_init(void);

    int graph_add_location(const char *name);

    int graph_add_path(int start, int end, int distance);
    int graph_remove_path(int start, int end);

    int graph_toggle_block(int start, int end);

    void graph_display(void);
    void graph_bfs(int start);
    void graph_dfs(int start);

    int graph_shortest_path(int start, int end, int path[], int *pathLength);
    void graph_print_shortest_path(int start, int end);

    int graph_location_count(void);
    int graph_is_valid(int location);
    const char *graph_location_name(int location);

#ifdef __cplusplus
}
#endif

#endif

import { $, state, saveState, notifyChange, locationName, escapeHTML, toast } from '../../js/store.js';

let activeMapRoute = null;
let activeRouteIds = [];
let selectsInitialized = false;

const DEFAULT_COORDS = {
  1: [105, 255], 2: [285, 135], 3: [285, 380],
  4: [535, 155], 5: [795, 290], 6: [565, 415]
};

function nodePoint(location, index) {
  if (DEFAULT_COORDS[location.id]) return DEFAULT_COORDS[location.id];
  const extraIndex = Math.max(0, index - 6);
  const col = extraIndex % 3;
  const row = Math.floor(extraIndex / 3);
  return [175 + col * 285, 70 + row * 82];
}

export function shortestPath(start, end) {
  start = Number(start); end = Number(end);
  const ids = state.locations.map(location => Number(location.id));
  if (!ids.includes(start) || !ids.includes(end)) return null;
  const distance = {}, previous = {}, visited = new Set();
  ids.forEach(id => { distance[id] = Infinity; });
  distance[start] = 0;

  while (visited.size < ids.length) {
    let current = null;
    for (const id of ids) {
      if (!visited.has(id) && (current === null || distance[id] < distance[current])) current = id;
    }
    if (current === null || distance[current] === Infinity) break;
    if (current === end) break;
    visited.add(current);

    for (const path of state.paths) {
      if (path.blocked) continue;
      const a = Number(path.a), b = Number(path.b);
      const neighbor = a === current ? b : b === current ? a : null;
      if (neighbor === null || visited.has(neighbor)) continue;
      const edgeDistance = Number(path.distance);
      if (!Number.isFinite(edgeDistance) || edgeDistance < 0) continue;
      const nextDistance = distance[current] + edgeDistance;
      if (nextDistance < distance[neighbor]) {
        distance[neighbor] = nextDistance;
        previous[neighbor] = current;
      }
    }
  }

  if (distance[end] === Infinity) return null;
  const idsInPath = [end];
  while (idsInPath[0] !== start) {
    const parent = previous[idsInPath[0]];
    if (parent === undefined) return null;
    idsInPath.unshift(parent);
  }
  return { distance: distance[end], ids: idsInPath, names: idsInPath.map(locationName) };
}

function neighbors(id) {
  return state.paths
    .filter(path => !path.blocked && (Number(path.a) === Number(id) || Number(path.b) === Number(id)))
    .map(path => Number(path.a) === Number(id) ? Number(path.b) : Number(path.a))
    .sort((a, b) => a - b);
}

function traverse(start, type) {
  start = Number(start);
  if (!state.locations.some(location => Number(location.id) === start)) return [];
  const visited = new Set();
  const result = [];
  if (type === 'bfs') {
    const queue = [start]; visited.add(start);
    while (queue.length) {
      const current = queue.shift(); result.push(locationName(current));
      for (const neighbor of neighbors(current)) {
        if (!visited.has(neighbor)) { visited.add(neighbor); queue.push(neighbor); }
      }
    }
  } else {
    const visit = current => {
      visited.add(current); result.push(locationName(current));
      for (const neighbor of neighbors(current)) if (!visited.has(neighbor)) visit(neighbor);
    };
    visit(start);
  }
  return result;
}

function renderLocationSelects() {
  const options = state.locations.map(location =>
    `<option value="${location.id}">${location.id} — ${escapeHTML(location.name)}</option>`
  ).join('');
  ['route-start', 'route-end', 'path-a', 'path-b', 'traversal-start', 'product-location'].forEach(id => {
    const select = $(id);
    if (select) {
      const previous = select.value;
      select.innerHTML = options;
      if ([...select.options].some(option => option.value === previous)) select.value = previous;
    }
  });
  if (!selectsInitialized) {
    if (state.locations.some(location => Number(location.id) === 1)) $('route-start').value = '1';
    if (state.locations.some(location => Number(location.id) === 4)) $('route-end').value = '4';
    selectsInitialized = true;
  }
}

function renderLocations() {
  $('location-cards').innerHTML = state.locations.map(location =>
    `<div class="location-card"><div class="location-number">${location.id}</div><b>${escapeHTML(location.name)}</b><small>Warehouse node ${location.id}</small></div>`
  ).join('') || '<p class="sub">No locations configured yet.</p>';
}

function renderPaths() {
  $('paths-table').innerHTML = state.paths.length ? `<table><thead><tr><th>From</th><th>To</th><th>Distance</th><th>Status</th><th>Action</th></tr></thead><tbody>${state.paths.map((path, index) =>
    `<tr><td>${escapeHTML(locationName(path.a))}</td><td>${escapeHTML(locationName(path.b))}</td><td>${path.distance} m</td><td>${path.blocked ? '<span class="path-blocked">Blocked</span>' : '<span class="pill">Open</span>'}</td><td><button class="secondary" data-toggle-path="${index}">${path.blocked ? 'Reopen' : 'Block path'}</button></td></tr>`
  ).join('')}</tbody></table>` : '<p class="sub">No paths configured.</p>';
}

function renderWarehouseMap() {
  const host = $('warehouse-map');
  if (!host) return;
  const points = new Map();
  state.locations.forEach((location, index) => points.set(Number(location.id), nodePoint(location, index)));
  const activePairs = new Set();
  for (let i = 0; i < activeRouteIds.length - 1; i++) {
    activePairs.add([activeRouteIds[i], activeRouteIds[i + 1]].sort((a, b) => a - b).join('-'));
  }

  const edges = state.paths.map(path => {
    const a = Number(path.a), b = Number(path.b);
    const p1 = points.get(a), p2 = points.get(b);
    if (!p1 || !p2) return '';
    const key = [a, b].sort((x, y) => x - y).join('-');
    const onRoute = activePairs.has(key) && !path.blocked;
    const mx = (p1[0] + p2[0]) / 2, my = (p1[1] + p2[1]) / 2;
    const label = `${path.distance}m`;
    return `<g class="map-edge-group"><line class="map-edge ${path.blocked ? 'is-blocked' : ''} ${onRoute ? 'is-route' : ''}" x1="${p1[0]}" y1="${p1[1]}" x2="${p2[0]}" y2="${p2[1]}"/><rect class="map-edge-label-bg" x="${mx - 20}" y="${my - 11}" width="40" height="18" rx="7"/><text class="map-edge-label" x="${mx}" y="${my + 2}">${label}</text></g>`;
  }).join('');

  const nodes = state.locations.map((location, index) => {
    const [x, y] = points.get(Number(location.id));
    const isRoute = activeRouteIds.includes(Number(location.id));
    const isStart = isRoute && activeRouteIds[0] === Number(location.id);
    const isEnd = isRoute && activeRouteIds[activeRouteIds.length - 1] === Number(location.id);
    const typeClass = isStart ? 'is-start' : isEnd ? 'is-end' : isRoute ? 'is-route' : '';
    const width = Math.min(148, Math.max(92, location.name.length * 7 + 28));
    const safeName = escapeHTML(location.name);
    return `<g class="map-node ${typeClass}" transform="translate(${x} ${y})"><rect class="map-node-card" x="${-width / 2}" y="-29" width="${width}" height="58" rx="13"/><circle class="map-node-dot" cx="${-width / 2 + 15}" cy="0" r="4"/><text class="map-node-id" x="${-width / 2 + 27}" y="-6">NODE ${location.id}</text><text class="map-node-name" x="${-width / 2 + 12}" y="9">${safeName.length > 18 ? safeName.slice(0, 17) + '…' : safeName}</text></g>`;
  }).join('');

  host.innerHTML = `<svg class="warehouse-svg" viewBox="0 0 930 500" preserveAspectRatio="xMidYMid meet" aria-label="Warehouse floor plan with routes and locations">
    <defs><pattern id="floor-grid" width="28" height="28" patternUnits="userSpaceOnUse"><path d="M 28 0 L 0 0 0 28" fill="none" stroke="#e8eef5" stroke-width="1"/></pattern></defs>
    <rect x="0" y="0" width="930" height="500" rx="18" fill="url(#floor-grid)"/>
    <text x="30" y="34" class="map-zone-title">WAREHOUSE FLOOR PLAN</text><text x="30" y="52" class="map-zone-subtitle">Nodes = zones / aisles · Lines = walkable paths</text>
    ${edges}${nodes}
    <g class="map-dock-label" transform="translate(28 448)"><rect width="180" height="30" rx="8"/><text x="12" y="19">↗ Dispatch & receiving</text></g>
  </svg>`;

  const summary = $('map-route-summary');
  if (summary) {
    if (activeRouteIds.length && activeMapRoute) {
      const names = activeRouteIds.map(locationName);
      const route = shortestPath(activeMapRoute.start, activeMapRoute.end);
      summary.innerHTML = route
        ? `<div class="map-route-distance">${route.distance} <small>metres</small></div><div class="map-route-nodes">${route.names.map((name, i) => `<span>${escapeHTML(name)}</span>${i < route.names.length - 1 ? '<b>→</b>' : ''}`).join(' ')}</div>`
        : '<span class="map-no-route">No open route between the selected locations.</span>';
    } else {
      summary.textContent = 'Select a start and destination to preview a route. Blocked paths are shown in red.';
    }
  }
}

export function highlightRoute(route) {
  if (route && route.ids && route.ids.length) {
    activeMapRoute = { start: Number(route.ids[0]), end: Number(route.ids[route.ids.length - 1]) };
    activeRouteIds = route.ids.map(Number);
  } else {
    activeMapRoute = null;
    activeRouteIds = [];
  }
  renderWarehouseMap();
}

export function refreshGraph() {
  renderLocationSelects();
  renderLocations();
  renderPaths();
  if (activeMapRoute) {
    const recalculated = shortestPath(activeMapRoute.start, activeMapRoute.end);
    activeRouteIds = recalculated ? recalculated.ids : [];
  }
  renderWarehouseMap();
}

export function initGraph() {
  $('graph-add-location-form').addEventListener('submit', event => {
    event.preventDefault();
    const name = $('graph-location-name').value.trim();
    if (!name) return toast('Enter a location name.');
    if (state.locations.length >= 20) return toast('Maximum of 20 locations reached.');
    const id = state.locations.reduce((max, location) => Math.max(max, Number(location.id)), 0) + 1;
    state.locations.push({ id, name });
    saveState(); notifyChange(); event.target.reset(); toast(`Location ${id} added to the map.`);
  });

  $('path-form').addEventListener('submit', event => {
    event.preventDefault();
    const a = Number($('path-a').value), b = Number($('path-b').value), distance = Number($('path-distance').value);
    if (!state.locations.some(l => Number(l.id) === a) || !state.locations.some(l => Number(l.id) === b) || a === b || !Number.isInteger(distance) || distance <= 0) {
      return toast('Choose two different valid locations and a positive distance.');
    }
    let path = state.paths.find(item => (Number(item.a) === a && Number(item.b) === b) || (Number(item.a) === b && Number(item.b) === a));
    if (path) { path.distance = distance; path.blocked = false; }
    else state.paths.push({ a, b, distance, blocked: false });
    saveState(); notifyChange(); event.target.reset(); toast('Path added or updated. Map refreshed.');
  });

  $('paths-table').addEventListener('click', event => {
    const button = event.target.closest('[data-toggle-path]');
    if (!button) return;
    const path = state.paths[Number(button.dataset.togglePath)];
    if (!path) return;
    path.blocked = !path.blocked;
    saveState(); notifyChange();
    if (activeMapRoute) {
      const reroute = shortestPath(activeMapRoute.start, activeMapRoute.end);
      highlightRoute(reroute);
      if (reroute) toast(`Path updated. Route recalculated: ${reroute.distance} m.`);
      else toast('Path blocked. No alternate route is currently available.');
    } else toast(path.blocked ? 'Path blocked. Routes will avoid it.' : 'Path reopened.');
  });

  $('route-form').addEventListener('submit', event => {
    event.preventDefault();
    const route = shortestPath($('route-start').value, $('route-end').value);
    highlightRoute(route);
    $('route-result').innerHTML = route
      ? `<b>Shortest route · ${route.distance} m</b><br>${route.names.map(escapeHTML).join(' <span class="route-arrow">→</span> ')}`
      : 'No open route found between these locations. Try reopening a blocked path.';
  });

  $('traversal-form').addEventListener('submit', event => {
    event.preventDefault();
    const type = $('traversal-type').value;
    const output = traverse($('traversal-start').value, type);
    $('traversal-result').innerHTML = output.length
      ? `<b>${type.toUpperCase()} traversal · ${output.length} location(s) reached</b><br>${output.map(escapeHTML).join(' <span class="route-arrow">→</span> ')}`
      : 'No reachable locations found.';
  });

  window.addEventListener('warehouse:changed', refreshGraph);
  refreshGraph();
}

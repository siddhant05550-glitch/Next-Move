export const $ = (id) => document.getElementById(id);

const defaultLocations = [
  { id: 1, name: 'Dispatch dock' }, { id: 2, name: 'Aisle A' },
  { id: 3, name: 'Aisle B' }, { id: 4, name: 'Aisle C' },
  { id: 5, name: 'Cold store' }, { id: 6, name: 'Returns bay' }
];
const defaultPaths = [
  { a: 1, b: 2, distance: 4, blocked: false }, { a: 1, b: 3, distance: 5, blocked: false },
  { a: 2, b: 4, distance: 6, blocked: false }, { a: 3, b: 4, distance: 3, blocked: false },
  { a: 2, b: 5, distance: 9, blocked: false }, { a: 4, b: 5, distance: 4, blocked: false },
  { a: 4, b: 6, distance: 5, blocked: false }, { a: 3, b: 6, distance: 10, blocked: false }
];
const defaultInventory = [
  { id: 150, name: 'Cable ties', quantity: 85, location: 3 },
  { id: 101, name: 'Copper wire roll', quantity: 40, location: 2 },
  { id: 205, name: 'LED panel', quantity: 12, location: 4 },
  { id: 58, name: 'Pallet wrap', quantity: 30, location: 3 },
  { id: 117, name: 'Safety gloves', quantity: 120, location: 2 },
  { id: 342, name: 'Vaccine cooler box', quantity: 6, location: 5 },
  { id: 263, name: 'Returned drill', quantity: 2, location: 6 }
];
function load(key, fallback) {
  try {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) : JSON.parse(JSON.stringify(fallback));
  } catch {
    return JSON.parse(JSON.stringify(fallback));
  }
}

export const state = {
  locations: load('nm_locations', defaultLocations),
  paths: load('nm_paths', defaultPaths),
  inventory: load('nm_inventory', defaultInventory),
  orders: load('nm_orders', []),
  nextOrderId: Number(localStorage.getItem('nm_next_order') || 1001)
};

export function saveState() {
  try {
    localStorage.setItem('nm_locations', JSON.stringify(state.locations));
    localStorage.setItem('nm_paths', JSON.stringify(state.paths));
    localStorage.setItem('nm_inventory', JSON.stringify(state.inventory));
    localStorage.setItem('nm_orders', JSON.stringify(state.orders));
    localStorage.setItem('nm_next_order', String(state.nextOrderId));
  } catch (error) {
    console.warn('Could not save warehouse state in this browser.', error);
  }
}

export function notifyChange() {
  window.dispatchEvent(new CustomEvent('warehouse:changed'));
}

export function locationName(id) {
  return state.locations.find((location) => location.id === Number(id))?.name || 'Unknown';
}

export function findProduct(id) {
  return state.inventory.find((product) => product.id === Number(id));
}

export function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[char]);
}

export function toast(message) {
  const node = $('toast');
  if (!node) return;
  node.textContent = message;
  node.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => node.classList.remove('show'), 2800);
}

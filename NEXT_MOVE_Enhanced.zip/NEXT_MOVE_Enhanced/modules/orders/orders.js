/* ============================================================
   ORDERS MODULE — SHIVAM
   Browser demo for order intake, priority queue, quantity editing,
   stock reservation, picking, packing, dispatch and delivery.
   The C++ source in c_cpp_reference implements the matching workflow.
   ============================================================ */
import { $, state, saveState, notifyChange, findProduct, escapeHTML, toast } from '../../js/store.js';
import { shortestPath, highlightRoute } from '../graph/graph.js';

const PRIORITY_RANK = { Critical: 4, High: 3, Normal: 2, Low: 1 };
const ACTIVE_STATUSES = ['Picking', 'Packed', 'Out for Delivery', 'Delivered'];
const CLOSED_STATUSES = ['Out of Stock', 'Cancelled'];

function migrateOrders() {
  state.orders.forEach(order => {
    if (order.status === 'Pending') order.status = 'New';
    if (order.status === 'Processed') order.status = 'Delivered';
    if (!order.customer) order.customer = 'Walk-in Customer';
    if (!order.priority || !PRIORITY_RANK[order.priority]) order.priority = 'Normal';
    if (!order.createdAt) order.createdAt = Number(order.order_id) || Date.now();
    if (typeof order.stockDeducted !== 'boolean') order.stockDeducted = false;
    if (!order.note && order.status === 'New') order.note = 'Customer order received; waiting in the priority queue.';
  });
  saveState();
}

function prioritySorted(orders) {
  return [...orders].sort((a, b) =>
    (PRIORITY_RANK[b.priority] || 0) - (PRIORITY_RANK[a.priority] || 0) ||
    Number(a.createdAt || a.order_id) - Number(b.createdAt || b.order_id) ||
    a.order_id - b.order_id
  );
}

function renderOrderStats() {
  const pending = prioritySorted(state.orders.filter(order => order.status === 'New'));
  $('orders-pending-count').textContent = pending.length;
  $('orders-processed-count').textContent = state.orders.filter(order => ACTIVE_STATUSES.includes(order.status)).length;
  $('orders-closed-count').textContent = state.orders.filter(order => CLOSED_STATUSES.includes(order.status)).length;
  $('orders-next-id').textContent = pending.length ? `#${pending[0].order_id}` : '—';
  const queueCount = $('queue-count');
  if (queueCount) queueCount.textContent = `${state.orders.length} total · ${pending.length} waiting`;
}

function priorityClass(priority) {
  return `priority-${String(priority || 'Normal').toLowerCase().replace(/[^a-z]/g, '')}`;
}

function statusClass(status) {
  return `status-${String(status || '').toLowerCase().replace(/[^a-z]+/g, '-')}`;
}

function actionMarkup(order) {
  const id = Number(order.order_id);
  if (order.status === 'New' || order.status === 'Out of Stock') {
    return `<div class="order-action-stack"><div class="quantity-editor"><input class="qty-edit" data-qty-order="${id}" type="number" min="1" value="${Math.max(1, Number(order.quantity) || 1)}" aria-label="New quantity for order ${id}"><button class="mini-action" data-save-qty="${id}" type="button">Save qty</button></div><small class="action-hint">${order.status === 'New' ? 'Editable until picking starts' : 'Adjust quantity to retry'}</small></div>`;
  }
  if (order.status === 'Picking') return `<button class="mini-action" data-advance-order="${id}" type="button">Mark packed <span>→</span></button>`;
  if (order.status === 'Packed') return `<button class="mini-action" data-advance-order="${id}" type="button">Dispatch order <span>→</span></button>`;
  if (order.status === 'Out for Delivery') return `<button class="mini-action" data-advance-order="${id}" type="button">Mark delivered <span>✓</span></button>`;
  if (order.status === 'Delivered') return '<span class="finished-text">✓ Completed</span>';
  if (order.status === 'Cancelled') return '<span class="muted-text">Cancelled</span>';
  return '<span class="muted-text">Review stock / quantity</span>';
}

function renderOrders() {
  renderOrderStats();
  const waiting = prioritySorted(state.orders.filter(order => order.status === 'New'));
  const active = state.orders.filter(order => ACTIVE_STATUSES.includes(order.status)).sort((a, b) => a.order_id - b.order_id);
  const closed = state.orders.filter(order => CLOSED_STATUSES.includes(order.status)).sort((a, b) => b.order_id - a.order_id);
  const ordered = [...waiting, ...active, ...closed];

  $('orders-table').innerHTML = ordered.length ? `<table class="orders-live-table"><thead><tr><th>Order</th><th>Customer</th><th>Product / SKU</th><th>Qty</th><th>Priority</th><th>Stage</th><th>Route / details</th><th>Live action</th></tr></thead><tbody>${ordered.map((order, index) => {
    const routeText = order.routeNames?.length
      ? `${order.routeNames.join(' → ')}${Number.isFinite(order.routeDistance) ? ` · ${order.routeDistance} m` : ''}`
      : (order.note || 'Waiting for pick route');
    const queuePosition = order.status === 'New' ? `<small class="queue-position">QUEUE ${index + 1}</small>` : '';
    return `<tr class="${order.status === 'New' ? 'queued-row' : ''}"><td><b class="order-id">#${order.order_id}</b>${queuePosition}</td><td>${escapeHTML(order.customer || 'Walk-in Customer')}</td><td><span class="product-name">${escapeHTML(order.product_name || 'Unknown product')}</span><small class="sku-label">SKU ${escapeHTML(order.product_id)}</small></td><td><b>${Number(order.quantity) || 0}</b></td><td><span class="priority-pill ${priorityClass(order.priority)}">${escapeHTML(order.priority || 'Normal')}</span></td><td><span class="status-pill ${statusClass(order.status)}">${escapeHTML(order.status)}</span></td><td class="route-cell" title="${escapeHTML(routeText)}">${escapeHTML(routeText)}</td><td>${actionMarkup(order)}${['New', 'Out of Stock', 'Picking', 'Packed'].includes(order.status) ? `<button class="cancel-order-button" data-cancel-order="${order.order_id}" type="button">Cancel order</button>` : ''}</td></tr>`;
  }).join('')}</tbody></table>` : '<div class="empty-state"><div class="empty-icon">↗</div><b>No customer orders yet</b><p>Create the first customer order above. It will appear here with its selected priority.</p></div>';

  const selectedValue = $('order-product').value;
  const options = state.inventory.map(product => `<option value="${product.id}">${product.id} — ${escapeHTML(product.name)} (${product.quantity} in stock)</option>`).join('');
  $('order-product').innerHTML = options || '<option value="">No products available</option>';
  if ([...$('order-product').options].some(option => option.value === selectedValue)) $('order-product').value = selectedValue;
  $('order-product').disabled = state.inventory.length === 0;
}

function getNextOrder() {
  return prioritySorted(state.orders.filter(order => order.status === 'New'))[0] || null;
}

function startPickingNextOrder() {
  const order = getNextOrder();
  if (!order) return toast('There are no new orders waiting for picking.');

  const product = findProduct(order.product_id);
  if (!product) {
    order.status = 'Cancelled';
    order.note = 'Product no longer exists in inventory.';
    saveState(); notifyChange();
    return toast(`Order #${order.order_id} cancelled: product not found.`);
  }
  if (product.quantity < order.quantity) {
    order.status = 'Out of Stock';
    order.note = `Insufficient stock: ${order.quantity} required, ${product.quantity} available. Reduce quantity or restock the item, then retry.`;
    saveState(); notifyChange();
    return toast(`Order #${order.order_id} needs ${order.quantity - product.quantity} more unit(s).`);
  }

  const dispatch = state.locations.find(location => Number(location.id) === 1) || state.locations[0];
  const route = dispatch ? shortestPath(dispatch.id, product.location) : null;
  if (!route) return toast('No open route to this product. Reopen a path in Graph before picking.');

  // Reserve stock at the moment picking starts, so another order cannot take the same units.
  product.quantity -= order.quantity;
  order.stockDeducted = true;
  order.status = 'Picking';
  order.routeIds = route.ids;
  order.routeNames = route.names;
  order.routeDistance = route.distance;
  order.note = `Picking route calculated with Dijkstra: ${route.names.join(' → ')} (${route.distance} m). Stock reserved.`;
  highlightRoute(route);
  saveState(); notifyChange();
  toast(`Picking started for #${order.order_id} · ${order.priority} priority · ${route.distance} m route.`);
}

function advanceOrder(orderId) {
  const order = state.orders.find(item => Number(item.order_id) === Number(orderId));
  if (!order) return toast('Order not found.');
  const next = { Picking: 'Packed', Packed: 'Out for Delivery', 'Out for Delivery': 'Delivered' }[order.status];
  if (!next) return toast('This order cannot move to the next stage.');
  order.status = next;
  order.note = next === 'Packed' ? 'Items picked and packed; ready for dispatch.'
    : next === 'Out for Delivery' ? 'Dispatched from warehouse; delivery is in progress.'
      : 'Delivery completed.';
  saveState(); notifyChange();
  toast(`Order #${order.order_id} moved to ${next}.`);
}

function saveOrderQuantity(orderId) {
  const order = state.orders.find(item => Number(item.order_id) === Number(orderId));
  const input = document.querySelector(`[data-qty-order="${Number(orderId)}"]`);
  const quantity = Number(input?.value);
  if (!order || !['New', 'Out of Stock'].includes(order.status)) return toast('Quantity can only be changed before picking.');
  if (!Number.isInteger(quantity) || quantity < 1) return toast('Enter a quantity of at least 1.');
  order.quantity = quantity;
  order.status = 'New';
  order.note = `Quantity updated live to ${quantity}. Waiting in the priority queue.`;
  saveState(); notifyChange();
  const product = findProduct(order.product_id);
  if (product && product.quantity < quantity) toast(`Order updated. Stock warning: only ${product.quantity} unit(s) available.`);
  else toast(`Order #${order.order_id} quantity updated to ${quantity}.`);
}

function cancelOrder(orderId) {
  const order = state.orders.find(item => Number(item.order_id) === Number(orderId));
  if (!order || !['New', 'Out of Stock', 'Picking', 'Packed'].includes(order.status)) return toast('Orders can only be cancelled before dispatch.');
  if (order.stockDeducted) {
    const product = findProduct(order.product_id);
    if (product) product.quantity += Number(order.quantity) || 0;
    order.stockDeducted = false;
  }
  order.status = 'Cancelled';
  order.note = 'Cancelled before dispatch; reserved stock restored if picking had started.';
  saveState(); notifyChange(); toast(`Order #${order.order_id} cancelled.`);
}

export function refreshOrders() { renderOrders(); }

export function initOrders() {
  migrateOrders();
  $('order-form').addEventListener('submit', event => {
    event.preventDefault();
    const product = findProduct($('order-product').value);
    const quantity = Number($('order-qty').value);
    const customer = $('order-customer').value.trim();
    const priority = $('order-priority').value;
    if (!product) return toast('Select a product first.');
    if (!customer) return toast('Enter the customer name.');
    if (!Number.isInteger(quantity) || quantity <= 0) return toast('Quantity must be at least 1.');
    const order = {
      order_id: state.nextOrderId++, product_id: product.id, product_name: product.name,
      quantity, customer, priority, status: 'New', note: 'Customer order received; waiting in the priority queue.',
      createdAt: Date.now(), stockDeducted: false, routeIds: [], routeNames: [], routeDistance: null
    };
    state.orders.push(order);
    saveState(); notifyChange(); event.target.reset(); $('order-qty').value = '1';
    toast(`Customer order #${order.order_id} created at ${priority} priority.`);
    if (product.quantity < quantity) toast(`Stock warning: ${product.quantity} unit(s) available for this SKU.`);
  });

  $('process-order').addEventListener('click', startPickingNextOrder);
  $('refresh-orders').addEventListener('click', () => { renderOrders(); toast('Order queue refreshed.'); });
  $('orders-table').addEventListener('click', event => {
    const advanceButton = event.target.closest('[data-advance-order]');
    if (advanceButton) return advanceOrder(Number(advanceButton.dataset.advanceOrder));
    const quantityButton = event.target.closest('[data-save-qty]');
    if (quantityButton) return saveOrderQuantity(Number(quantityButton.dataset.saveQty));
    const cancelButton = event.target.closest('[data-cancel-order]');
    if (cancelButton) return cancelOrder(Number(cancelButton.dataset.cancelOrder));
  });

  window.addEventListener('warehouse:changed', renderOrders);
  renderOrders();
}

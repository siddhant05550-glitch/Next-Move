# NEXT MOVE — Intelligent Warehouse Order Picking & Dynamic Route Optimization

NEXT MOVE is a student warehouse-operations prototype. It demonstrates customer order intake, inventory updates, urgency-aware picking, route optimization over a warehouse graph, and the journey from order creation to delivery.

## What's new in this version

- **Priority-based order queue:** Critical, High, Normal and Low. Higher urgency goes first; orders at the same priority remain FIFO by order ID / arrival time.
- **End-to-end fulfilment flow:** New → Picking → Packed → Out for Delivery → Delivered.
- **Customer order intake:** Add a customer, product, quantity and requested priority.
- **Live quantity edits:** Change a queued order's quantity before picking. Out-of-stock orders can be adjusted and retried.
- **Stock reservation:** Inventory is deducted when picking starts, preventing the same units from being promised to another queued order in this demo.
- **Cancellation before dispatch:** Cancel an order before it leaves the warehouse. If stock was reserved during picking, it is returned to inventory.
- **2D warehouse floor map:** Locations are nodes and paths are edges; distances are labelled. A selected shortest path is highlighted. Blocked paths are marked in red and route calculations avoid them.
- **Graph algorithms:** BFS, DFS and Dijkstra remain available in the Graph module.
- **Inventory tools:** Add and search products, adjust quantity, map products to warehouse locations, and review low stock.
- **Browser persistence:** The web demo stores its state in the current browser's `localStorage`.

## Project structure

```text
NEXT_MOVE_Three_Modules/
├── index.html
├── style.css
├── js/
│   ├── app.js
│   └── store.js
├── modules/
│   ├── graph/graph.js
│   ├── inventory/inventory.js
│   └── orders/orders.js
└── c_cpp_reference/
    ├── graph.c / graph.h          # C: warehouse graph, BFS, DFS, Dijkstra
    ├── inventory.c / inventory.h  # C: hash table, linked lists, BST
    ├── orders.cpp / orders.h      # C++: order class and priority queue
    └── main.cpp                   # C++: main console application
```

## Run the professional browser UI

1. Extract the ZIP file and open the `NEXT_MOVE_Three_Modules` folder in VS Code.
2. Install the **Live Server** extension if it is not installed.
3. Right-click `index.html` and choose **Open with Live Server**.
4. Open the Orders section to place a customer order. Select a priority, then choose **Start highest-priority pick** to reserve stock and calculate the route. Use each order's action button to progress through packing, dispatch and delivery.
5. Open Graph to see the 2D map. Use the route form to highlight any route, or block a path to test rerouting.

A local web server is required because this UI uses JavaScript modules. It does not require Python or an external database.

## Build the C/C++ console application (Windows / MinGW)

Open a terminal inside `NEXT_MOVE_Three_Modules/c_cpp_reference` and run:

```powershell
gcc -std=c11 -Wall -Wextra -c inventory.c graph.c
g++ -std=c++17 -Wall -Wextra main.cpp orders.cpp inventory.o graph.o -o warehouse.exe
.\warehouse.exe
```

The C files contain the core graph and inventory data structures. The C++ application calls those C functions and uses `std::priority_queue` (a binary heap) to select the next customer order. The console application's Orders menu includes order creation, priority queue display, picking, workflow progression, quantity updates, cancellation, availability checks and history.

For Linux or macOS, use the same compile commands and run `./warehouse` after naming the output `warehouse` instead of `warehouse.exe`.

## Important architecture note

The browser UI and C/C++ console program currently demonstrate the same workflow in **separate runnable versions**. The browser modules do not directly call the C/C++ functions; the browser version uses JavaScript and `localStorage`, while the C/C++ version runs in the terminal. This keeps the demo easy to run without a backend server, but changes made in one version do not automatically appear in the other.

The warehouse map uses illustrative distances and simulated locations; it is not indoor GPS or live warehouse telemetry. This is a local student prototype, not a secure multi-user production system.

## Team module ownership

- **Siddhant — Graph:** `modules/graph/graph.js`; C reference: `c_cpp_reference/graph.c` and `graph.h`.
- **Parv — Inventory:** `modules/inventory/inventory.js`; C reference: `c_cpp_reference/inventory.c` and `inventory.h`.
- **Shivam — Orders:** `modules/orders/orders.js`; C++ reference: `c_cpp_reference/orders.cpp`, `orders.h` and `main.cpp`.

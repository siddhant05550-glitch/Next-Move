@echo off
setlocal
cd /d "%~dp0"
echo.
echo [1/2] Compiling C data-structure modules...
gcc -std=c11 -Wall -Wextra -c inventory.c graph.c
if errorlevel 1 goto :error
echo.
echo [2/2] Building C++ warehouse application...
g++ -std=c++17 -Wall -Wextra main.cpp orders.cpp inventory.o graph.o -o warehouse.exe
if errorlevel 1 goto :error
echo.
echo Build successful. Starting NEXT MOVE...
echo.
warehouse.exe
goto :end
:error
echo.
echo Build failed. Check the compiler output above.
 pause
exit /b 1
:end
pause
endlocal

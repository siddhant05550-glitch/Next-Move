/*
 * orders.h — C++ order manager for NEXT MOVE
 * Uses a priority_queue for urgency-first selection; same-priority orders
 * keep arrival order by comparing their monotonically increasing order IDs.
 */
#ifndef ORDERS_H
#define ORDERS_H

#include <queue>
#include <string>
#include <vector>

const int DISPATCH_DOCK = 1;

class Order
{
public:
    int orderId;
    int productId;
    std::string productName;
    std::string customerName;
    int quantity;
    std::string priority;   // Critical, High, Normal, Low
    std::string status;     // New, Picking, Packed, Out for Delivery, Delivered, etc.
    std::string note;
    bool stockDeducted;

    Order(int oid, int pid, const std::string &pname, int qty,
          const std::string &customer = "Walk-in Customer",
          const std::string &priorityLevel = "Normal");
    void display() const;
};

struct OrderPriorityCompare
{
    bool operator()(const Order &left, const Order &right) const;
};

class OrderManager
{
private:
    std::vector<Order> orders;   // single source of truth for active and completed orders
    int nextOrderId;

    static int priorityRank(const std::string &priority);
    Order *findOrder(int orderId);
    const Order *findOrder(int orderId) const;

public:
    explicit OrderManager(int startId = 1001);

    int addOrder(int productId, int quantity,
                 const std::string &customer = "Walk-in Customer",
                 const std::string &priority = "Normal");
    void displayPending() const;
    void displayHistory() const;
    bool searchOrder(int orderId) const;
    bool cancelOrder(int orderId);
    bool processNextOrder();              // starts picking on highest-priority new order
    bool advanceOrder(int orderId);       // Picking -> Packed -> Out for Delivery -> Delivered
    bool updateQuantity(int orderId, int quantity);
    void checkAvailability(int productId, int quantity) const;

    int pendingCount() const;
    int processedCount() const;
};

#endif

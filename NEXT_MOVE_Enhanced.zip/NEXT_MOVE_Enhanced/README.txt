NEXT MOVE — ENHANCED THREE-MODULE WAREHOUSE PROTOTYPE

WHAT'S INCLUDED
- Customer order creation with Critical / High / Normal / Low priority.
- Priority-first order picking, FIFO for equal priorities.
- Order workflow: New -> Picking -> Packed -> Out for Delivery -> Delivered.
- Live quantity changes before picking; retry after an out-of-stock result.
- Stock reservation at pick start and stock restoration when cancelled before dispatch.
- Visual 2D warehouse floor map with locations, distances, blocked paths and highlighted Dijkstra route.
- BFS, DFS, Dijkstra, path blocking and dynamic route recalculation.
- Inventory add/search/update and low-stock reporting.
- C graph + inventory data structures, plus a C++ main console app using std::priority_queue.

RUN THE BROWSER UI
1. Extract the ZIP.
2. Open the NEXT_MOVE_Three_Modules folder in VS Code.
3. Right-click index.html and select Open with Live Server.
4. Use Orders to create and fulfil a customer order. Use Graph to visualize routes.

BUILD THE C/C++ APPLICATION (run in c_cpp_reference)
  gcc -std=c11 -Wall -Wextra -c inventory.c graph.c
  g++ -std=c++17 -Wall -Wextra main.cpp orders.cpp inventory.o graph.o -o warehouse.exe
  .\warehouse.exe

IMPORTANT
The browser UI and C/C++ console app are separate runnable prototypes; the browser UI does not directly call the C/C++ source. Browser state is saved in that browser's localStorage. The map is a simulated warehouse layout with illustrative metre distances, not indoor GPS.
See README.md for the full feature and architecture guide.

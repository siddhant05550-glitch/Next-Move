/* Main shell only: navigation + dashboard. Feature logic lives in the 3 owner modules. */
import { $, state, locationName, escapeHTML } from './store.js';
import { initGraph } from '../modules/graph/graph.js';
import { initInventory } from '../modules/inventory/inventory.js';
import { initOrders } from '../modules/orders/orders.js';

const pageDetails = {
  dashboard: ['Dashboard', 'A clear view of your warehouse operations.'],
  graph: ['Graph · Siddhant', 'Warehouse locations, paths, traversal and route optimization.'],
  inventory: ['Inventory · Parv', 'Products, quantities, storage locations and low-stock reports.'],
  orders: ['Orders · Shivam', 'Priority queue, live quantity updates and order-to-delivery workflow.']
};

function renderDashboard() {
  $('stat-products').textContent = state.inventory.length;
  $('stat-units').textContent = state.inventory.reduce((sum, product) => sum + product.quantity, 0);
  $('stat-low').textContent = state.inventory.filter(product => product.quantity < 10).length;
  $('stat-locations').textContent = state.locations.length;
  $('stat-pending').textContent = state.orders.filter(order => ['New', 'Pending'].includes(order.status)).length;
  $('stat-processed').textContent = state.orders.filter(order => ['Picking', 'Packed', 'Out for Delivery', 'Delivered', 'Processed'].includes(order.status)).length;
  const items = [...state.inventory].sort((a, b) => a.id - b.id).slice(0, 6);
  $('dashboard-inventory').innerHTML = items.length ? `<table><thead><tr><th>ID</th><th>Product</th><th>Quantity</th><th>Location</th></tr></thead><tbody>${items.map(product =>
    `<tr><td>${product.id}</td><td class="product-name">${escapeHTML(product.name)}</td><td><span class="pill ${product.quantity < 10 ? 'low' : ''}">${product.quantity} units</span></td><td>${escapeHTML(locationName(product.location))}</td></tr>`
  ).join('')}</tbody></table>` : '<p class="sub">Inventory is empty.</p>';
}

function showSection(section) {
  document.querySelectorAll('.section').forEach(node => node.classList.toggle('active', node.id === section));
  document.querySelectorAll('.nav').forEach(button => button.classList.toggle('active', button.dataset.section === section));
  const details = pageDetails[section] || pageDetails.dashboard;
  $('page-title').textContent = details[0];
  $('page-subtitle').textContent = details[1];
  if (section === 'dashboard') renderDashboard();
}

document.querySelectorAll('.nav').forEach(button => button.addEventListener('click', () => showSection(button.dataset.section)));
document.querySelectorAll('[data-go]').forEach(button => button.addEventListener('click', () => showSection(button.dataset.go)));
window.addEventListener('warehouse:changed', renderDashboard);

// Each person's module initializes its own event handlers and rendering.
initGraph();
initInventory();
initOrders();
renderDashboard();
